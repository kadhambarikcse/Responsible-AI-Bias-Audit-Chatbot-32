import { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowDownToLine,
  BookOpenCheck,
  Check,
  ChevronRight,
  CircleHelp,
  ClipboardCheck,
  FileText,
  HeartHandshake,
  Layers2,
  Scale,
  ShieldCheck,
  Sparkles,
  UsersRound,
} from 'lucide-react';
import { findBiasFindings, type BiasFinding } from './lib/bias-rules';
import { buildComparisonSummary } from './lib/comparison';

type CategoryId = 'gender' | 'age' | 'disability' | 'language';
type Mode = 'single' | 'compare';
type Severity = 'none' | 'low' | 'moderate' | 'elevated';
type Finding = BiasFinding;
type CategoryResult = {
  id: CategoryId;
  label: string;
  severity: Severity;
  findings: Finding[];
  summary: string;
  suggestion: string;
};
type ResponseResult = { label: string; text: string; results: CategoryResult[] };

const CATEGORIES: { id: CategoryId; label: string; short: string; description: string }[] = [
  { id: 'gender', label: 'Gender', short: 'Gender assumptions', description: 'Roles, pronouns, and gendered defaults' },
  { id: 'age', label: 'Age', short: 'Age assumptions', description: 'Age stereotypes and capability claims' },
  { id: 'disability', label: 'Disability', short: 'Disability language', description: 'Deficit framing and accessibility assumptions' },
  { id: 'language', label: 'Language', short: 'Language & accent', description: 'Language proficiency and accent stereotypes' },
];

const SUGGESTIONS: Record<CategoryId, string> = {
  gender: 'Describe the specific person or evidence rather than inferring a role, trait, or ability from gender. Consider neutral pronouns where identity is unknown.',
  age: 'Name the relevant experience, needs, or evidence directly. Avoid using age as a proxy for capability or preference.',
  disability: 'Use precise, respectful language and avoid assuming needs or abilities. When relevant, focus on access barriers and ask what support is preferred.',
  language: 'Separate language access needs from intelligence or competence. Consider plain language, interpretation, and the person’s preferred communication style.',
};

const EXAMPLES = {
  gender: 'The nurse should ask his supervisor for help. Women are naturally more caring, while men are better suited to leadership.',
  age: 'Older workers cannot adapt to new software, and young employees are always inexperienced.',
  disability: 'People with disabilities are helpless and confined to a wheelchair.',
  language: 'The applicant has a thick accent, so they may not be able to explain complex ideas. We should provide an interpreter if they prefer one.',
  comparisonA: 'Men are naturally better at engineering, while women are better suited to caring roles.',
  comparisonB: "Engineering and caring roles should be open to everyone. Evaluate each person's skills, interests, and experience.",
};

const CAVEAT = 'These are preliminary rule-based indicators, not proof of discrimination. A phrase may be quoted, reclaimed, negated, or relevant in context. Review the surrounding conversation and evidence; do not infer intent or label a person or group.';

function severityFor(count: number): Severity {
  if (count === 0) return 'none';
  if (count === 1) return 'low';
  if (count <= 3) return 'moderate';
  return 'elevated';
}

function assess(text: string, selected: CategoryId[], label: string): ResponseResult {
  const results = selected.map((id) => {
    const category = CATEGORIES.find((item) => item.id === id)!;
    const findings: Finding[] = findBiasFindings(text, id);
    const severity = severityFor(findings.length);
    return {
      id,
      label: category.label,
      severity,
      findings,
      summary: findings.length
        ? `${findings.length} phrase${findings.length === 1 ? '' : 's'} matched one or more review rules.`
        : 'No phrases matched the selected rules in this response.',
      suggestion: SUGGESTIONS[id],
    };
  });
  return { label, text, results };
}

function csvCell(value: string | number): string {
  const text = String(value);
  const spreadsheetSafe = /^[\u0000-\u0020]*[=+\-@]/.test(text) ? `'${text}` : text;
  return `"${spreadsheetSafe.replace(/"/g, '""')}"`;
}

function downloadCsv(mode: Mode, responses: ResponseResult[]) {
  const rows: (string | number)[][] = [
    ['FairBot Audit — preliminary review export'],
    ['Mode', mode === 'single' ? 'Single response' : 'Compare two responses'],
    ['Caveat', CAVEAT],
    [],
    ['Response', 'Input text', 'Category', 'Severity', 'Finding phrase', 'Rule watched', 'Explanation', 'Suggestion'],
  ];
  for (const response of responses) {
    for (const category of response.results) {
      if (category.findings.length) {
        for (const finding of category.findings) {
          rows.push([response.label, response.text, category.label, category.severity, finding.phrase, finding.rule, finding.explanation, category.suggestion]);
        }
      } else {
        rows.push([response.label, response.text, category.label, 'none', 'No match', 'Selected rules', category.summary, category.suggestion]);
      }
    }
  }
  const content = `\uFEFF${rows.map((row) => row.map((cell) => csvCell(cell)).join(',')).join('\r\n')}`;
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = 'fairbot-audit-review.csv';
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function ResultCategory({ category }: { category: CategoryResult }) {
  return (
    <section className="category-result" data-testid={`result-category-${category.id}`}>
      <div className="category-result-top">
        <h4>{category.label}</h4>
        <span className={`severity ${category.severity}`} data-testid={`severity-${category.id}`}>
          {category.severity === 'none' ? 'No match' : `${category.severity} indicator`}
        </span>
      </div>
      <p className="finding-text">{category.summary}</p>
      {category.findings.length > 0 ? category.findings.map((finding, index) => (
        <div className="evidence-line" key={`${finding.phrase}-${index}`} data-testid={`evidence-${category.id}-${index}`}>
          <ChevronRight size={13} aria-hidden="true" />
          <span><span className="quote">“{finding.phrase}”</span> <b>{finding.rule}.</b> {finding.explanation}</span>
        </div>
      )) : (
        <div className="evidence-line"><Check size={13} aria-hidden="true" /><span>No selected rule phrases detected. This does not establish that a response is free from bias.</span></div>
      )}
      <div className="suggestion"><b>Review prompt:</b> {category.suggestion}</div>
    </section>
  );
}

function ResponseCard({ response }: { response: ResponseResult }) {
  return (
    <article className="response-card" data-testid={`response-results-${response.label.toLowerCase().replace(/\s+/g, '-')}`}>
      <div className="response-card-head"><strong>{response.label}</strong><span>{response.text.length} characters reviewed</span></div>
      {response.results.map((category) => (
        <ResultCategory key={category.id} category={category} />
      ))}
    </article>
  );
}

function ComparisonOverview({ responses }: { responses: [ResponseResult, ResponseResult] }) {
  const comparison = buildComparisonSummary(responses);

  return (
    <section className="comparison-overview" aria-label="Response A and Response B comparison" data-testid="response-comparison">
      <h3 className="comparison-conclusion" data-testid="comparison-conclusion">{comparison.conclusion}</h3>
      <div className="comparison-sides">
        {comparison.sides.map((side, index) => (
          <article className="comparison-side" key={side.label} data-testid={`comparison-side-${index === 0 ? 'a' : 'b'}`}>
            <div className="comparison-side-head">
              <h4>{side.label}</h4>
              <div className="comparison-count">
                <strong data-testid={`comparison-count-${index === 0 ? 'a' : 'b'}`}>{side.phraseCount}</strong>
                <span>detected phrases</span>
              </div>
            </div>
            <div className="comparison-category-label">Categories detected</div>
            {side.detectedCategories.length > 0 ? (
              <div className="comparison-categories" data-testid={`comparison-categories-${index === 0 ? 'a' : 'b'}`}>
                {side.detectedCategories.map((category) => <span className="comparison-category" key={category}>{category}</span>)}
              </div>
            ) : (
              <p className="comparison-no-category" data-testid={`comparison-categories-${index === 0 ? 'a' : 'b'}`}>
                No selected categories matched. This does not establish that the response is unbiased.
              </p>
            )}
          </article>
        ))}
      </div>
      <p className="comparison-note" data-testid="comparison-note">{comparison.note}</p>
    </section>
  );
}

function App() {
  const [mode, setMode] = useState<Mode>('single');
  const [responseA, setResponseA] = useState('');
  const [responseB, setResponseB] = useState('');
  const [selected, setSelected] = useState<CategoryId[]>(['gender', 'age', 'disability', 'language']);
  const [error, setError] = useState('');
  const [results, setResults] = useState<ResponseResult[] | null>(null);

  const totalFindings = useMemo(() => results?.reduce((sum, response) =>
    sum + response.results.reduce((count, category) => count + category.findings.length, 0), 0) ?? 0, [results]);
  const inputA = responseA.trim();
  const inputB = responseB.trim();

  const toggleCategory = (id: CategoryId) => {
    setSelected((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
    setResults(null);
    setError('');
  };

  const runAudit = () => {
    if (!inputA) {
      setError('Add a chatbot response before starting your review.');
      setResults(null);
      return;
    }
    if (mode === 'compare' && !inputB) {
      setError('Add a second chatbot response to compare both samples.');
      setResults(null);
      return;
    }
    if (!selected.length) {
      setError('Select at least one review category.');
      setResults(null);
      return;
    }
    setError('');
    const next = [assess(inputA, selected, mode === 'compare' ? 'Response A' : 'Response')];
    if (mode === 'compare') next.push(assess(inputB, selected, 'Response B'));
    setResults(next);
    window.setTimeout(() => document.getElementById('audit-results')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 30);
  };

  const useExample = (kind: keyof typeof EXAMPLES) => {
    if (kind === 'comparisonA') {
      setMode('compare'); setResponseA(EXAMPLES.comparisonA); setResponseB(EXAMPLES.comparisonB);
    } else {
      setMode('single'); setResponseA(EXAMPLES[kind]); setResponseB('');
    }
    setError('');
    setResults(null);
  };

  const changeMode = (next: Mode) => {
    setMode(next);
    setError('');
    setResults(null);
  };

  return (
    <div className="app-shell">
      <header className="topbar">
        <a href="#top" className="brand" aria-label="FairBot Audit home" data-testid="link-home">
          <span className="brand-mark"><Scale size={20} strokeWidth={1.8} aria-hidden="true" /></span>
          <span><span className="brand-name">FairBot Audit</span><span className="brand-sub">Responsible AI field notes</span></span>
        </a>
        <div className="top-meta"><span>Learn by looking closely</span><span className="local-pill"><span className="local-dot" />Runs in your browser</span></div>
      </header>

      <main id="top" className="page-wrap">
        <section className="hero" aria-labelledby="hero-title">
          <div>
            <div className="eyebrow"><span className="eyebrow-line" />A beginner-friendly audit notebook</div>
            <h1 id="hero-title">Look closer.<br /><em>Ask better questions.</em></h1>
            <p className="hero-copy">Responsible AI starts with careful observation. Paste a chatbot answer to check for language that may signal gender, age, disability, or language bias — then review the evidence in context.</p>
          </div>
          <aside className="hero-note"><strong>What this tool can tell you</strong>It can point to phrases worth a second look. It cannot determine intent, prove discrimination, or replace a human review.</aside>
        </section>

        <div className="workspace">
          <section className="panel" aria-labelledby="input-heading">
            <div className="panel-head">
              <div>
                <div className="panel-kicker">01 / Add a sample</div>
                <h2 id="input-heading" className="panel-title">Start with the words</h2>
                <p className="panel-caption">Use text from a chatbot response. Your text stays in this browser tab and is not saved or sent anywhere.</p>
              </div>
              <div className="mode-toggle" role="group" aria-label="Review mode">
                <button type="button" aria-pressed={mode === 'single'} onClick={() => changeMode('single')} data-testid="button-mode-single"><FileText size={13} />One response</button>
                <button type="button" aria-pressed={mode === 'compare'} onClick={() => changeMode('compare')} data-testid="button-mode-compare"><Layers2 size={13} />Compare two</button>
              </div>
            </div>
            <div className="panel-body">
              <label className="field-label" htmlFor="response-a">
                <span>{mode === 'compare' ? 'Response A' : 'Chatbot response'}</span><small>Required · max 8,000 characters</small>
              </label>
              <div className="text-field-wrap">
                <textarea id="response-a" className="response-field" maxLength={8000} value={responseA} onChange={(event) => { setResponseA(event.target.value); setResults(null); setError(''); }} placeholder="Paste the chatbot’s response here. Include enough surrounding text to help you interpret any flagged phrase." data-testid="input-response-a" />
                <div className="char-count"><span>Response text</span><span className={responseA.length >= 7900 ? 'limit' : ''}>{responseA.length.toLocaleString()} / 8,000</span></div>
              </div>
              {mode === 'compare' && (
                <div className="text-field-wrap">
                  <label className="field-label" htmlFor="response-b" style={{ marginTop: 17 }}>
                    <span>Response B</span><small>Required · max 8,000 characters</small>
                  </label>
                  <textarea id="response-b" className="response-field secondary" maxLength={8000} value={responseB} onChange={(event) => { setResponseB(event.target.value); setResults(null); setError(''); }} placeholder="Paste a second response to compare category-by-category." data-testid="input-response-b" />
                  <div className="char-count"><span>Comparison text</span><span className={responseB.length >= 7900 ? 'limit' : ''}>{responseB.length.toLocaleString()} / 8,000</span></div>
                </div>
              )}
              <div className="example-row" aria-label="Example responses">
                <span className="tiny-label">Try an example</span>
                <button type="button" className="example-chip" onClick={() => useExample('gender')} data-testid="button-example-gender">Gender roles</button>
                <button type="button" className="example-chip" onClick={() => useExample('age')} data-testid="button-example-age">Age assumptions</button>
                <button type="button" className="example-chip" onClick={() => useExample('disability')} data-testid="button-example-disability">Disability language</button>
                <button type="button" className="example-chip" onClick={() => useExample('language')} data-testid="button-example-language">Language access</button>
                <button type="button" className="example-chip" onClick={() => useExample('comparisonA')} data-testid="button-example-compare">Comparison</button>
              </div>
              <div className="section-rule" />
              <div className="category-head"><h3>Choose what to look for</h3><span>{selected.length} of 4 selected</span></div>
              <div className="category-grid">
                {CATEGORIES.map((category) => (
                  <label className={`category-option ${selected.includes(category.id) ? 'selected' : ''}`} key={category.id} data-testid={`option-category-${category.id}`}>
                    <input type="checkbox" checked={selected.includes(category.id)} onChange={() => toggleCategory(category.id)} data-testid={`checkbox-category-${category.id}`} />
                    <span><span className="category-name">{category.short}</span><span className="category-desc">{category.description}</span></span>
                  </label>
                ))}
              </div>
              {error && <div className="form-error" role="alert" data-testid="status-validation-error">{error}</div>}
              <div className="actions-row">
                <span className="privacy-copy">No account. No upload. Your pasted text disappears when you leave or refresh this page.</span>
                <button type="button" className="primary-btn" onClick={runAudit} data-testid="button-run-audit"><ClipboardCheck size={15} />Review response</button>
              </div>
            </div>
          </section>

          <section id="audit-results" className="panel results-panel" aria-labelledby="results-heading" aria-live="polite">
            <div className="panel-head">
              <div>
                <div className="panel-kicker">02 / Read the evidence</div>
                <h2 id="results-heading" className="panel-title">Your review notes</h2>
                <p className="panel-caption">Indicators are prompts for human judgment, not verdicts about a chatbot or the people it mentions.</p>
              </div>
            </div>
            {!results ? (
              <div className="empty-results" data-testid="empty-results">
                <div className="empty-illustration"><BookOpenCheck size={33} strokeWidth={1.4} /></div>
                <h3>Your notes will appear here</h3>
                <p>Paste one response or choose compare mode, select review categories, then start your audit.</p>
                <div className="empty-steps"><b>1</b> Add text <ChevronRight size={12} /><b>2</b> Choose lenses <ChevronRight size={12} /><b>3</b> Review</div>
              </div>
            ) : (
              <div className="result-content animate-enter" data-testid="audit-results-content">
                <div className="results-toolbar">
                  <div className="eyebrow"><span className="eyebrow-line" />Review complete</div>
                  <button type="button" className="export-btn" onClick={() => downloadCsv(mode, results)} data-testid="button-export-csv"><ArrowDownToLine size={14} />Export CSV</button>
                </div>
                {mode === 'compare' && results[0] && results[1] ? (
                  <ComparisonOverview responses={[results[0], results[1]]} />
                ) : (
                  <div className="result-summary" data-testid="summary-findings">
                    <div><h3 className="summary-title">{totalFindings === 0 ? 'No selected phrases matched' : 'A few places to look closer'}</h3><p className="summary-copy">{totalFindings === 0 ? 'The selected rules did not detect their watched phrases. Other forms of bias may still be present.' : 'Review each highlighted phrase alongside its surrounding context before drawing conclusions.'}</p></div>
                    <div className="finding-count"><strong>{totalFindings}</strong><span>matches</span></div>
                  </div>
                )}
                <div className="notice" data-testid="notice-caveat"><AlertTriangle size={15} /><span>{CAVEAT}</span></div>
                <div className="response-results">
                  {results.map((response) => <ResponseCard key={response.label} response={response} />)}
                </div>
              </div>
            )}
          </section>
        </div>

        <section className="method-section" aria-label="About responsible AI and the checker">
          <article className="info-card">
            <h2 className="info-heading"><HeartHandshake size={19} />Responsible AI, in practice</h2>
            <p>Responsible AI means building and using systems with attention to people, context, and consequences. A bias review asks whether wording makes unfair assumptions, excludes people, or treats similar situations differently. It starts a conversation; it does not settle one.</p>
          </article>
          <article className="info-card">
            <h2 className="info-heading"><CircleHelp size={19} />A transparent first pass</h2>
            <p>FairBot uses visible, hand-written phrase rules in your browser. A match means “consider this wording,” not “bias found.” Rules may miss indirect bias and can flag neutral, quoted, or relevant language. Read the full answer and consider who may be affected.</p>
          </article>
          <article className="info-card">
            <h2 className="info-heading"><Sparkles size={19} />What the rules watch</h2>
            <p>Each selected lens checks a small set of explicit phrase patterns. The examples below are the phrases and patterns that can prompt a review; the checker does not use a trained model or judge intent.</p>
            <div className="rule-list">
              <div className="rule-pill"><b>Gender</b>Group + “are / should / can’t / naturally”; gendered roles and pronouns</div>
              <div className="rule-pill"><b>Age</b>Age-group + capability claims; “too old,” “too young,” and group references</div>
              <div className="rule-pill"><b>Disability</b>“Helpless,” “confined to a wheelchair,” “suffers from,” group references</div>
              <div className="rule-pill"><b>Language</b>“Broken English,” “thick accent,” “speak proper English,” language status + claims</div>
            </div>
          </article>
          <article className="info-card">
            <h2 className="info-heading"><UsersRound size={19} />Make the next review thoughtful</h2>
            <p>Check whether the language is describing an individual or generalizing about a group. Look for evidence, counterexamples, and missing perspectives. A respectful rewrite should preserve useful meaning while removing assumptions.</p>
          </article>
        </section>

        <footer className="footer-note">
          <span><strong>FairBot Audit</strong> · A learning tool for careful, human-led review.</span>
          <span><ShieldCheck size={12} style={{ display: 'inline', verticalAlign: '-2px', marginRight: 5 }} />Browser-only by design. Nothing is saved or transmitted.</span>
        </footer>
      </main>
    </div>
  );
}

export default App;
