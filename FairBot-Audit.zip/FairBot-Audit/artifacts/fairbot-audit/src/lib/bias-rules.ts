export type CategoryId = 'gender' | 'age' | 'disability' | 'language';

export type BiasFinding = {
  phrase: string;
  rule: string;
  explanation: string;
};

type BiasRule = {
  pattern: RegExp;
  rule: string;
  explanation: string;
};

const stopAtClauseBreak = String.raw`(?=\s+(?:because|since|while|whereas|although|but)\b|[,.!?;]|$)`;

const RULES: Record<CategoryId, BiasRule[]> = {
  gender: [
    {
      pattern: new RegExp(
        String.raw`\b(?:men|women|boys|girls|males|females)\s+(?:are|were)\s+(?:(?:naturally|generally|typically|usually|inherently|always|often)\s+)?(?:better|worse|best|least)\s+suited\s+(?:to|for)\s+[^,.!?;\n]{1,70}?${stopAtClauseBreak}`,
        'gi',
      ),
      rule: 'Gender-based role suitability',
      explanation:
        'This assigns suitability for a role or kind of work based on gender rather than the individual’s skills or experience.',
    },
    {
      pattern: new RegExp(
        String.raw`\b(?:men|women|boys|girls|males|females)\s+(?:are|were)\s+(?:(?:naturally|generally|typically|usually|inherently|always|often)\s+)?(?:more|less|better|worse)\s+(?:(?:logical|rational|intelligent|technical|creative|capable|competent|caring|nurturing|emotional|strong|weak)\b|(?:at|in|for|with)\s+[^,.!?;\n]{1,55}?${stopAtClauseBreak})`,
        'gi',
      ),
      rule: 'Gender-based ability or trait claim',
      explanation:
        'This generalizes an ability, trait, or comparative advantage to a gender group instead of evaluating people individually.',
    },
    {
      pattern:
        /\b(?:men|women|boys|girls|males|females)\s+(?:are|were)\s+(?:naturally|generally|typically|usually|inherently|always|often)\s+(?:logical|rational|intelligent|technical|creative|capable|competent|caring|nurturing|emotional|strong|weak)\b/gi,
      rule: 'Gender stereotype about a group trait',
      explanation:
        'This presents a trait as typical of a gender group, which may reinforce a stereotype.',
    },
    {
      pattern:
        /\b(?:men|women|boys|girls|males|females)\s+(?:should|must|ought to)\s+(?:be\s+)?(?:primary\s+)?(?:caregivers?|providers?|leaders?|engineers?|nurses?|teachers?|assistants?|breadwinners?|care for|lead|provide|stay home)\b/gi,
      rule: 'Gendered role expectation',
      explanation:
        'This prescribes a responsibility or occupation for someone based on gender.',
    },
    {
      pattern:
        /\b(?:the\s+)?(?:nurse|teacher|assistant|secretary|caregiver|engineer|doctor|leader)\s+(?:should|must|can)\s+(?:ask|tell|call|report to|consult)\s+(?:his|her)\b/gi,
      rule: 'Gendered pronoun attached to a job role',
      explanation:
        'This may assume a person’s gender from their occupation; use a name or neutral pronoun when identity is unknown.',
    },
  ],
  age: [
    {
      pattern: new RegExp(
        String.raw`\b(?:older|elderly|senior|young|teenage|teenaged)\s+(?:people|workers|employees|adults|users|candidates|applicants)\s+(?:can't|cannot|are unable to|are incapable of|are always|are never|will not|won't|never)\s+[^,.!?;\n]{1,70}?${stopAtClauseBreak}`,
        'gi',
      ),
      rule: 'Age-based capability generalization',
      explanation:
        'This makes a broad claim about what people can do based on age rather than their individual abilities.',
    },
    {
      pattern: new RegExp(
        String.raw`\b(?:young|older|elderly|senior|teenage|teenaged)\s+(?:people|workers|employees|adults|users|candidates|applicants)\s+(?:are|were)\s+(?:always|never|inherently|naturally)\s+[^,.!?;\n]{1,65}?${stopAtClauseBreak}`,
        'gi',
      ),
      rule: 'Age stereotype',
      explanation:
        'This uses an absolute or inherent claim to characterize a group by age.',
    },
    {
      pattern: /\b(?:too old|too young|over the hill|past their prime|old dog|young and inexperienced)\b/gi,
      rule: 'Age-based dismissal',
      explanation:
        'This age-related phrase may dismiss someone’s ability or credibility without individual evidence.',
    },
  ],
  disability: [
    {
      pattern:
        /\b(?:people with disabilities|disabled people|disabled individuals|people with a disability|a disabled person|a person with a disability)\s+(?:are|is|can't|cannot|will never|are always)\s+(?:unable|incapable|helpless|dependent|unfit|incompetent|limited|a burden)\b/gi,
      rule: 'Disability-based ability generalization',
      explanation:
        'This assigns a limitation or dependence to disabled people as a group rather than considering an individual’s abilities and access needs.',
    },
    {
      pattern:
        /\b(?:confined to a wheelchair|suffers from|victim of|in spite of (?:their|his|her) disability|normal people|crippled|retarded|lame)\b/gi,
      rule: 'Potentially stigmatizing disability language',
      explanation:
        'This wording can frame disability as tragedy or deficiency, or use a term that is often offensive; check the speaker’s context and preference.',
    },
  ],
  language: [
    {
      pattern: new RegExp(
        String.raw`\b(?:non-native speakers?|people who (?:don't|do not) speak English|limited[- ]English speakers?|people with limited English)\s+(?:can't|cannot|are unable to|are less likely to|struggle to|should not|shouldn't|must not)\s+[^,.!?;\n]{1,70}?${stopAtClauseBreak}`,
        'gi',
      ),
      rule: 'Language background linked to ability',
      explanation:
        'This links language background to competence or capability without evidence about the individual.',
    },
    {
      pattern:
        /\b(?:broken English|bad English|poor English|thick accent|speak proper English|speak normally|speak correctly)\b/gi,
      rule: 'Potentially dismissive language or accent judgment',
      explanation:
        'This may treat one language variety or accent as inferior; consider whether the wording describes a specific communication need or stereotypes a speaker.',
    },
  ],
};

export function findBiasFindings(
  text: string,
  category: CategoryId,
): BiasFinding[] {
  const findings: BiasFinding[] = [];
  const seen = new Set<string>();

  for (const item of RULES[category]) {
    item.pattern.lastIndex = 0;
    let match: RegExpExecArray | null;

    while ((match = item.pattern.exec(text)) !== null) {
      const phrase = match[0].trim();
      const key = `${phrase.toLowerCase()}-${item.rule}`;

      if (!seen.has(key)) {
        findings.push({
          phrase,
          rule: item.rule,
          explanation: item.explanation,
        });
        seen.add(key);
      }

      if (match.index === item.pattern.lastIndex) {
        item.pattern.lastIndex++;
      }
    }
  }

  return findings;
}
