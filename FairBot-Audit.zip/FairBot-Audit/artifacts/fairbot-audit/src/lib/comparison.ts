export type ComparisonFindingInput = {
  phrase: string;
  rule: string;
  explanation: string;
};

export type ComparisonResponseInput = {
  label: string;
  results: {
    label: string;
    findings: ComparisonFindingInput[];
  }[];
};

export type ComparisonSide = {
  label: string;
  phraseCount: number;
  detectedCategories: string[];
};

export type ComparisonSummary = {
  sides: [ComparisonSide, ComparisonSide];
  conclusion: string;
  note: string;
};

function summarizeResponse(response: ComparisonResponseInput): ComparisonSide {
  const phrases = new Set<string>();
  const detectedCategories: string[] = [];

  for (const category of response.results) {
    if (category.findings.length > 0) {
      detectedCategories.push(category.label);
    }

    for (const finding of category.findings) {
      phrases.add(finding.phrase.toLocaleLowerCase());
    }
  }

  return {
    label: response.label,
    phraseCount: phrases.size,
    detectedCategories,
  };
}

export function buildComparisonSummary(
  responses: [ComparisonResponseInput, ComparisonResponseInput],
): ComparisonSummary {
  const [responseA, responseB] = responses.map(summarizeResponse) as [
    ComparisonSide,
    ComparisonSide,
  ];

  let conclusion: string;
  if (responseA.phraseCount > responseB.phraseCount) {
    conclusion = `${responseB.label} has fewer detected bias-related phrases than ${responseA.label}.`;
  } else if (responseB.phraseCount > responseA.phraseCount) {
    conclusion = `${responseA.label} has fewer detected bias-related phrases than ${responseB.label}.`;
  } else {
    conclusion = `Both responses have the same number of detected bias-related phrases. Neither has fewer detected matches.${responseA.phraseCount === 0 ? ' Zero detections do not mean either response is unbiased.' : ''}`;
  }

  return {
    sides: [responseA, responseB],
    conclusion,
    note: 'These are preliminary rule-based indicators, not a fairness score or proof of discrimination. Review the surrounding context; a match can be quoted or relevant, and no matches do not prove that a response is unbiased.',
  };
}
