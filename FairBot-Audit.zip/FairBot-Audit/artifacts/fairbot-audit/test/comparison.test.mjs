import assert from 'node:assert/strict';
import test from 'node:test';

import { buildComparisonSummary } from '../src/lib/comparison.ts';
import { findBiasFindings } from '../src/lib/bias-rules.ts';

const categories = [
  ['gender', 'Gender'],
  ['age', 'Age'],
  ['disability', 'Disability'],
  ['language', 'Language'],
];

const responseAText =
  'Men are naturally better at engineering, while women are better suited to caring roles.';
const responseBText =
  "Engineering and caring roles should be open to everyone. Evaluate each person's skills, interests, and experience.";

function analyze(label, text) {
  return {
    label,
    results: categories.map(([id, categoryLabel]) => ({
      label: categoryLabel,
      findings: findBiasFindings(text, id),
    })),
  };
}

test('comparison: supplied example shows A and B counts, categories, and fewer-phrases summary', () => {
  const summary = buildComparisonSummary([
    analyze('Response A', responseAText),
    analyze('Response B', responseBText),
  ]);

  assert.deepEqual(
    summary.sides.map((side) => side.phraseCount),
    [2, 0],
  );
  assert.deepEqual(summary.sides[0].detectedCategories, ['Gender']);
  assert.deepEqual(summary.sides[1].detectedCategories, []);
  assert.equal(
    summary.conclusion,
    'Response B has fewer detected bias-related phrases than Response A.',
  );

  const genderFindings = analyze('Response A', responseAText).results[0].findings;
  assert.ok(genderFindings.some((finding) => finding.phrase.toLowerCase() === 'men are naturally better at engineering'));
  assert.ok(genderFindings.some((finding) => finding.phrase.toLowerCase() === 'women are better suited to caring roles'));
  assert.ok(genderFindings.every((finding) => finding.explanation.trim()));
  assert.match(summary.note, /preliminary rule-based indicators/i);
  assert.match(summary.note, /context/i);
});

test('comparison: equal zero counts say neither has fewer and do not imply unbiased responses', () => {
  const neutral = 'Everyone is assessed using the same role-related criteria.';
  const summary = buildComparisonSummary([
    analyze('Response A', neutral),
    analyze('Response B', neutral),
  ]);

  assert.deepEqual(
    summary.sides.map((side) => side.phraseCount),
    [0, 0],
  );
  assert.match(summary.conclusion, /Neither has fewer detected matches/);
  assert.match(summary.conclusion, /do not mean either response is unbiased/);
});

test('comparison: equal nonzero counts also say neither response has fewer matches', () => {
  const summary = buildComparisonSummary([
    analyze('Response A', responseAText),
    analyze('Response B', responseAText),
  ]);

  assert.deepEqual(
    summary.sides.map((side) => side.phraseCount),
    [2, 2],
  );
  assert.match(summary.conclusion, /Neither has fewer detected matches/);
});

test('comparison: lists every detected bias category for the matching response', () => {
  const allCategoriesText =
    'Men are naturally better at engineering. Older workers cannot adapt to software. People with disabilities are helpless. Non-native speakers cannot handle complex tasks.';
  const summary = buildComparisonSummary([
    analyze('Response A', allCategoriesText),
    analyze('Response B', responseBText),
  ]);

  assert.deepEqual(summary.sides[0].detectedCategories, [
    'Gender',
    'Age',
    'Disability',
    'Language',
  ]);
  assert.deepEqual(summary.sides[1].detectedCategories, []);
});

test('comparison: recomputes the conclusion when a new response pair is analyzed', () => {
  const first = buildComparisonSummary([
    analyze('Response A', responseAText),
    analyze('Response B', responseBText),
  ]);
  const updated = buildComparisonSummary([
    analyze('Response A', responseBText),
    analyze('Response B', responseAText),
  ]);

  assert.match(first.conclusion, /Response B has fewer/);
  assert.match(updated.conclusion, /Response A has fewer/);
  assert.deepEqual(
    updated.sides.map((side) => side.phraseCount),
    [0, 2],
  );
});
