import assert from 'node:assert/strict';
import test from 'node:test';

import { findBiasFindings } from '../src/lib/bias-rules.ts';

const responseA =
  'Men are naturally better at engineering because they are more logical, while women are generally better suited to caring and support roles.';

const responseB =
  'Anyone with the relevant technical skills, qualifications, problem-solving ability, and experience can be suitable for an engineering job, regardless of gender.';

function assertFindingsExplainTheirEvidence(findings) {
  for (const finding of findings) {
    assert.ok(finding.phrase.trim(), 'each flag should show the exact matched phrase');
    assert.ok(finding.rule.trim(), 'each flag should name the rule');
    assert.ok(finding.explanation.trim(), 'each flag should explain why it was raised');
  }
}

test('gender: flags the two stereotypes in Response A with exact phrases and explanations', () => {
  const findings = findBiasFindings(responseA, 'gender');
  const phrases = findings.map((finding) => finding.phrase.toLowerCase());

  assert.ok(
    phrases.includes('men are naturally better at engineering'),
    `expected the engineering ability stereotype, got: ${phrases.join(' | ')}`,
  );
  assert.ok(
    phrases.includes('women are generally better suited to caring and support roles'),
    `expected the caring-role stereotype, got: ${phrases.join(' | ')}`,
  );
  assertFindingsExplainTheirEvidence(findings);
});

test('gender: leaves the skills-based Response B unflagged', () => {
  assert.deepEqual(findBiasFindings(responseB, 'gender'), []);
});

test('gender: leaves a neutral inclusive hiring statement unflagged', () => {
  assert.deepEqual(
    findBiasFindings(
      'Applicants of all genders are assessed using the same job-related criteria.',
      'gender',
    ),
    [],
  );
});

test('age: flags a broad age-based capability claim and explains it', () => {
  const findings = findBiasFindings(
    'Older workers cannot adapt to new software.',
    'age',
  );

  assert.ok(findings.some((finding) => /older workers cannot adapt/i.test(finding.phrase)));
  assertFindingsExplainTheirEvidence(findings);
});

test('age: leaves equal age-neutral criteria unflagged', () => {
  assert.deepEqual(
    findBiasFindings(
      'Applicants of all ages are assessed against the same role-related criteria.',
      'age',
    ),
    [],
  );
});

test('disability: flags generalized helplessness and explains it', () => {
  const findings = findBiasFindings(
    'People with disabilities are helpless and dependent.',
    'disability',
  );

  assert.ok(findings.some((finding) => /people with disabilities are helpless/i.test(finding.phrase)));
  assertFindingsExplainTheirEvidence(findings);
});

test('disability: leaves an accessibility description unflagged', () => {
  assert.deepEqual(
    findBiasFindings(
      'The venue offers a step-free entrance, captions, and an accessible restroom.',
      'disability',
    ),
    [],
  );
});

test('language: flags a language-background competence assumption and explains it', () => {
  const findings = findBiasFindings(
    'Non-native speakers cannot handle complex tasks.',
    'language',
  );

  assert.ok(findings.some((finding) => /non-native speakers cannot handle complex tasks/i.test(finding.phrase)));
  assertFindingsExplainTheirEvidence(findings);
});

test('language: leaves an optional interpretation offer unflagged', () => {
  assert.deepEqual(
    findBiasFindings(
      'Applicants may choose their preferred language, and an interpreter is available on request.',
      'language',
    ),
    [],
  );
});
